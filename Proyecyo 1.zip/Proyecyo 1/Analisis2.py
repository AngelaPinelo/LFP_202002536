from TE import Token
from TE import Error
from prettytable import PrettyTable

class Analizador2():
    def __init__(self):
        self.listaTokens = []
        self.listaErrores = []
        self.linea = 1
        self.columna = 0
        self.buffer = ''
        
    
    def imprimirDatos(self):
        print ('**************Lista Tokens************')
        for token in self.listaTokens:
            token.getTok()
        for error in self.listaErrores:
            error.getError()
    
    def agregar_token(self,caracter,token,linea,columna):
        self.listaTokens.append(Token(caracter,token,linea,columna))
        self.buffer = ''
        
    def agregar_error(self,caracter,descripcion,linea,columna):
        self.listaErrores.append(Error( caracter, descripcion, linea, columna))
        self.buffer=''
        
        
    def AnalisisLexico(self,cadena):
        text = cadena + '$'
        print (text)
        estado = 0
        option = True
        for caracter in text:
            #print (caracter)
            self.columna+=1
            option = True
            while option:
                if estado == 0:
                    option=False
                    if caracter == '~':
                        self.buffer+=caracter
                        #self.columna+=1                        
                        self.agregar_token(self.buffer, 'Virgulilla', self.linea, self.columna)
                    elif caracter =='<':
                        self.buffer+=caracter
                        #self.columna+=1                    
                        self.agregar_token(self.buffer, 'Menor que', self.linea, self.columna)
                    elif caracter =='>':
                        self.buffer+=caracter
                        #self.columna+=1                    
                        self.agregar_token(self.buffer, 'Mayor que', self.linea, self.columna)
                    elif caracter =='[':
                        self.buffer+=caracter
                        #self.columna+=1                    
                        self.agregar_token(self.buffer, 'Corchete que abre', self.linea, self.columna)
                    elif caracter ==':':
                        self.buffer+=caracter
                        #self.columna+=1                    
                        self.agregar_token(self.buffer, 'Dos puntos', self.linea, self.columna)
                    elif caracter ==']':
                        self.buffer+=caracter
                        #self.columna+=1                    
                        self.agregar_token(self.buffer, 'Corchete que cierra', self.linea, self.columna)
                    elif caracter ==',':
                        self.buffer+=caracter
                        #self.columna+=1                    
                        self.agregar_token(self.buffer, 'Coma', self.linea, self.columna)
                    elif caracter.isalpha():
                        self.buffer+= caracter                      
                        estado = 1
                    elif caracter == '"':
                        self.buffer+= caracter                
                        self.agregar_token(self.buffer, 'Comilla Doble', self.linea, self.columna)
                        estado = 2
                    elif caracter == "'":
                        self.buffer+= caracter
                        self.agregar_token(self.buffer, 'Comilla simple', self.linea, self.columna)                
                        estado = 3
                    else: 
                        if caracter =='\n':
                            self.linea+=1
                        elif caracter == '\r':
                            self.linea +=1
                        elif caracter == ' ':
                            pass
                        else: 
                            self.buffer += caracter
                            self.agregar_error(self.buffer,'Error Lexico',self.linea,self.columna)
                        
                elif estado == 1:
                    option=False
                    if caracter.isalpha():
                        self.buffer+= caracter                       
                    elif caracter.isdigit():
                        self.buffer+=caracter                       
                    elif caracter== '_':
                        self.buffer+=caracter
                    else: 
                        self.agregar_token(self.buffer, 'Identificador', self.linea, self.columna)
                        estado=0
                        option=True
                
                elif estado == 2:
                    option=False
                    if caracter!='"':
                        self.buffer+= caracter                        
                    else: 
                        self.agregar_token(self.buffer, 'Instrucción', self.linea, self.columna)
                        self.agregar_token('"', 'Comilla Doble',self.linea, self.columna )
                        estado=0
                        option=True
                
                elif estado == 3:
                    option=False
                    if caracter!="'":
                        self.buffer+= caracter                        
                    else: 
                        self.agregar_token(self.buffer, 'Instrucción', self.linea, self.columna)
                        self.agregar_token("'", 'Comilla Doble',self.linea, self.columna )
                        estado=0
                        option=True
    
    def impTokens(self):
        print("TABLA TOKENS")
        x = PrettyTable()
        x.field_names = ["Lexema", "Token", "Fila", "Columna"]
        for i in self.listaTokens:
            x.add_row(i.enviarDataTok())
        print(x)
        
    def impErrores(self):
        print("TABLA ERRORES")
        x = PrettyTable()
        x.field_names = ["lexema","Descripcion", "Fila", "Columna"]
        if len(self.listaErrores)==0:
            print('No hay errores')
        else:
            for i in self.listaErrores:
                x.add_row(i.enviarDataError())
            print(x)